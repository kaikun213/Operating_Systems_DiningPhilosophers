Operating_Systems_DiningPhilosophers

Run the application by importing it in eclipse and run the main-method in the program class.
Or compile it to a runnable jar file.

Log-file in the source folder.

Deadlock is detected by JVM. Application will close and print-out proper message in the console.
If the threads are not terminated by the shutdownNow() method of the executioner service, we shutdown the JVM itself to ensure that the program ends.

