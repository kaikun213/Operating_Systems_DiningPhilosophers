
public class Chopstick {
	
	private int id;
	
	public Chopstick(int id){
		this.setId(id);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
