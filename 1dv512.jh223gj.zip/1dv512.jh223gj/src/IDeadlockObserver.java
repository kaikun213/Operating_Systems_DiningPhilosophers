
public interface IDeadlockObserver {
	
	public void deadlockOccoured();

}
