

public class RunnablePhilosopher implements Runnable {
	
	Philosopher philosopher;
	
	public RunnablePhilosopher(Philosopher philosopher){
		this.philosopher = philosopher;
	}

	@Override
	public void run() {
		
	}

}
